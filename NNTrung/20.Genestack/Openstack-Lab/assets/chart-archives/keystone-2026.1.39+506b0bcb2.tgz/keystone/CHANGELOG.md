# Release notes

## 2026.1.0-141

- The keystone API keeps running under Apache httpd (mod_wsgi), now serving
  plain HTTP on the identity ``service`` endpoint port (5000); TLS is no
  longer terminated by Apache but by the nginx sidecar in front of it. Apache
  is retained (rather than switching to uwsgi like the other API charts) so
  that federated/external authentication modules
  (``mod_auth_openidc``/``mod_auth_mellon``/``mod_auth_gssapi``) remain
  available.
- Use a single dedicated client certificate (keystone-client) for all mutual TLS
  backend connections (MariaDB and RabbitMQ) instead of rendering separate
  certificates, and allow enabling mutual TLS to RabbitMQ independently via
  the tls.oslo_messaging value. The MariaDB client certificate secret was
  renamed from keystone-mariadb-client to keystone-client.
- Allow enabling TLS for the Keystone API and for the Keystone to MariaDB
  connection independently via the tls.identity and tls.oslo_db values, and
  use a dedicated client certificate when connecting to MariaDB over TLS
  instead of reusing the MariaDB server certificate on the client side.
- Allow users to supply custom annotations to fernet-keys and credentials-keys
  Secrets.
- Removed the unused non-admin database user secret ``keystone-db-user``. The
  service database connection string is generated from the ``oslo_db``
  endpoint definition and rendered directly into the service configuration
  file, so the dedicated user ``DB_CONNECTION`` secret was never mounted
  or referenced by any job or pod. The admin database secret used for
  ``ROOT_DB_CONNECTION`` is unaffected.
- The keystone-fernet-keys and keystone-credential-keys secrets are
  pre-install hooks annotated with helm.sh/resource-policy: keep, but set
  no helm.sh/hook-delete-policy. GitOps tools such as Argo CD re-run
  pre-install hooks on every sync and, absent a delete-policy, default to
  before-hook-creation -- deleting and recreating the populated secret
  empty each sync. The fernet/credential setup jobs then regenerate the
  keys, invalidating all issued tokens.
  
  Set helm.sh/hook-delete-policy: hook-failed so the kept secrets are never
  deleted, matching the existing resource-policy: keep intent. This has no
  effect on plain Helm installs: pre-install hooks run only on install, and
  a Secret hook never enters a failed state.
- Removed the unused ``endpoints.oslo_db.auth.admin.secret.tls`` and
  ``endpoints.oslo_messaging.auth.admin.secret.tls`` metadata.
- Making keystone credential secrets completely dynamically created.
  We need to keep those secrets when we delete release, but those
  helm complains that they exist if we do `helm upgrade --install`.
  Now the setup jobs are responsible for those secrets lifecycle.

### New Features

- The ``helm-toolkit.manifests.certificates`` template now accepts an
  optional ``secretName`` parameter. When provided, it sets the name of the
  rendered cert-manager ``Certificate`` (both ``metadata.name`` and
  ``spec.secretName``) instead of deriving it from the endpoint's
  ``host_fqdn_override.default.tls.secretName``.

### Upgrade Notes

- The charts no longer render ``Ingress`` resources, nor the auxiliary
  ``Service`` objects and TLS secrets that used to back them. Charts now
  deploy only the applications and their ClusterIP ``Service`` objects.
  Expose services outside the cluster by supplying the necessary objects
  through the ``.Values.extraObjects`` field, for example a Gateway API
  ``HTTPRoute`` (plus a ``BackendTLSPolicy`` for backend re-encryption) or,
  if preferred, an ``Ingress`` together with its ``Service``. Ready-to-use
  Gateway API examples are provided under
  ``values_overrides/<chart>/gateway.yaml``.
- The mTLS client certificate that each chart presents on outbound
  connections to MariaDB and RabbitMQ is now named after the chart-local
  value ``secrets.tls.client.<chart>`` rather than the shared
  ``endpoints.oslo_db.host_fqdn_override.default.tls.secretName``. This
  prevents a name collision for deployments whose values tooling renders
  endpoints from a single shared endpoint catalog, where the ``oslo_db``
  endpoint (and therefore its ``secretName``) is identical across every
  chart. The pod ``client-certs`` volume already references the same
  chart-local value, so the certificate and its mount remain in lockstep.
  No action is required for existing deployments: the default
  ``secrets.tls.client.<chart>`` value matches the previously rendered
  certificate name.

### API Changes

- Removed all ingress-related values from the charts: the
  ``manifests.ingress*``, ``manifests.service_ingress*`` and
  ``manifests.secret_ingress_tls`` toggles, the ``endpoints.ingress``
  controller endpoint and the ``network.<service>.ingress`` blocks. The
  now-unused ``helm-toolkit.manifests.ingress``,
  ``helm-toolkit.manifests.service_ingress`` and
  ``helm-toolkit.manifests.secret_ingress_tls`` helpers were removed as well.

### Bug Fixes

- Populate ``[cache] memcache_servers`` from the ``oslo_cache`` internal
  memcache endpoint for heat, neutron, trove, and zaqar when a cache section
  exists and ``memcache_servers`` has not already been set by user overrides.
  
  This brings these charts in line with other OpenStack-Helm services that
  already populate ``memcache_servers`` from the ``oslo_cache`` endpoint while
  keeping explicit overrides authoritative.
- Corrected ``rabbit_quorum_queues`` to ``rabbit_quorum_queue`` in every
  chart's ``values.yaml``. The oslo.messaging RabbitMQ driver only
  recognizes the singular option name (see
  `impl_rabbit.py <https://github.com/openstack/oslo.messaging/blob/b5593e2a733bf1ca86be8182f12a17d2d973fb5a/oslo_messaging/_drivers/impl_rabbit.py#L165>`_),
  so the plural form set by every chart since
  Change-Id ``I331e5e86744cbf935a1414399f0dc8e0ce76e4c0`` was silently
  ignored and quorum queues were never actually enabled via that setting.
- The ``keystone-fernet-keys`` and ``keystone-credential-keys`` Secrets
  rendered their ``data`` field as an empty/null value instead of an empty
  map. GitOps tools such as Argo CD track and re-apply these Secrets on
  every sync (since they are Helm ``pre-install`` hooks), and a patch that
  contains an explicit ``null`` for ``data`` clears any keys already
  present, wiping out the fernet/credential keys written out-of-band by
  the ``keystone-fernet-setup``/``keystone-credential-setup`` jobs and the
  fernet rotation cronjob. ``data`` is now rendered as an empty map
  (``{}``), which merges as a no-op instead of clearing the field.

## 2026.1.0

- Allow users to add additional sources to the Projected Volume that is mounted
  at /etc/keystone/keystone.conf.d/ so they may more easily override configs or provide
  additional configs for the various services in the chart.
- Remove endpoint-update.py from db-sync Job.
  The script was originally introduced in OSH to work around a
  limitation where `keystone-manage bootstrap` would not update endpoints
  once created. That limitation was resolved when upstream keystone added
  endpoint updates support to bootstrap.
- Provide a WSGI script for Apache to use to start up Keystone since Keystone
  stopped shipping their own entrypoint. This is done in a way that users can
  override it and the container has less moving pieces at startup.
- Ensure all errors go to the kubenertes logs and not to a file in the
  container.
- Use Keystone native wsgi script keystone/wsgi/api.py
  instead of the wsgi wrapper script provided by the
  keystone chart.
- Adds optional settings backoffLimit and activeDeadlineSeconds
  to the keystone bootstrap job.
- Add support for etcSources to db-sync job.

### New Features

- Update default ingress classes and annotations for charts to make them implementation
  agnostic. They used to be nginx specific because we always used ingress-nginx as the most
  common choice. Ingress-nginx is deprecated and will become unmaintained in Feb/2026.
  
  Now for all test jobs we use HAProxy Ingress as the default implementation. However any
  other implementation can be used as far as it suppports annotations similar to
  'nginx.ingress.kubernetes.io/rewrite-target' or 'haproxy.org/path-rewrite' which are
  used in many OpenStack-Helm charts.
- Added an extraObjects list to every chart to allow for adding extra
  Kubernetes objects along side the chart without modifying the chart.
  It has the added benefit of using Helm's built in templating so
  you are able to utilize other values supplied to the chart.
- Added emptyDir mounted at /var/lock and set OSLO_LOCK_PATH env var to
  this path for oslo.concurrency support in all OpenStack services.

### Upgrade Notes

- Support for Helm 2 has been removed by removal of the helm3_hook value across all charts.
  It is no longer possible to set helm3_hook to False to support Helm 2.

## 2025.2.0

- Annotate credential and fernet keys secrets with the Helm keep policy.
  While helm does not clean up hook resources today, their documentation
  says that it is coming and users should annotate resources they do not
  expect to be deleted appropriately. Some GitOps tools like ArgoCD
  implement the cleanup today as part of their Helm support.

### New Features

- Update apparmor values to use security_context instead of annotations.
- Add support for runtimeClassName and priorityClassName

## 2025.1.0

- Use oslo.middleware healthcheck endpoint for liveness and readiness

### Bug Fixes

- Fix the number of max active fernet keys

## 2024.2.0

Before 2024.2.0 all the OpenStack-Helm charts were versioned independently.
Here we provide all the release notes for the chart for all versions before 2024.2.0.

- 0.1.0 Initial Chart
- 0.1.1 UPDATE
- 0.1.2 UPDATE
- 0.1.3 UPDATE
- 0.1.4 UPDATE
- 0.1.5 Revert clusterissuer change
- 0.1.6 Fix typo in subPath entry
- 0.1.7 Move rabbit-init to dynamic dependency
- 0.1.8 Change Issuer to ClusterIssuer
- 0.1.9 Add helm.sh/hook related annotations
- 0.1.10 Update RBAC apiVersion from /v1beta1 to /v1
- 0.1.11 Remove congress residue
- 0.1.12 Add helm hook conditional
- 0.1.13 Fix Error - wrong number of args for set
- 0.1.14 Remove setup helm hooks
- 0.2.0 Remove support for releases before T
- 0.2.1 Remove paste ini config settings
- 0.2.2 Make python script PEP8 compliant
- 0.2.3 Adding rabbitmq TLS logic
- 0.2.4 Use policies in yaml format
- 0.2.5 Mount rabbitmq TLS secret
- 0.2.6 Modify default probe timings
- 0.2.7 Add Ussuri release support
- 0.2.8 Remove member bootstrap logic
- 0.2.9 Add Victoria and Wallaby releases support
- 0.2.10 Make internal TLS more robust
- 0.2.11 Add missing slash
- 0.2.12 Helm 3 - Fix Job Labels
- 0.2.13 Helm 3 - Fix more Job Labels
- 0.2.14 Update htk requirements repo
- 0.2.15 Reduce log chattiness
- 0.2.16 Remove extra fsGroup
- 0.2.17 Update default image references
- 0.2.18 Remove default policy
- 0.2.19 Revert Reduce log chattiness
- 0.2.20 Enable taint toleration for Openstack services
- 0.2.21 Updated naming for subchart compatibility
- 0.2.22 Remove older values overrides
- 0.2.23 Remove usage of six
- 0.2.24 Remove unused admin port in keystone
- 0.2.25 Migrated CronJob resource to batch/v1 API version & PodDisruptionBudget to policy/v1
- 0.2.26 Add Xena and Yoga values overrides
- 0.2.27 Use LOG.warning instead of deprecated LOG.warn
- 0.2.28 Added OCI registry authentication
- 0.2.29 Support TLS endpoints
- 0.2.30 Distinguish between port number of internal endpoint and binding port number
- 0.3.0 Remove support for Train and Ussuri
- 0.3.1 Replace node-role.kubernetes.io/master with control-plane
- 0.3.2 Add Zed overrides
- 0.3.3 Add 2023.1 overrides
- 0.3.4 Add Ubuntu Jammy overrides
- 0.3.5 Add 2023.2 Ubuntu Jammy overrides
- 0.3.6 Use region option in keystone endpoint-update.py
- 0.3.7 Make keystone TLS configuration granular
- 0.3.8 Enable custom annotations for Openstack pods
- 0.3.9 Add 2024.1 overrides
- 0.3.10 Allow custom annotations on jobs
- 0.3.11 Fix custom annotations when helm3_hook is disabled
- 0.3.12 Enable custom annotations for Openstack secrets
- 0.3.13 Update images used by default
- 0.3.14 Align db scripts with sqlalchemy 2.0
- 0.3.15 Use quay.io/airshipit/kubernetes-entrypoint:latest-ubuntu_focal by default
- 0.3.16 Align db scripts with Sqlalchemy 2
- 0.3.17 Add 2024.2 Ubuntu Jammy overrides
- 0.3.18 Update Chart.yaml apiVersion to v2
- 2024.2.0 Update version to align with the Openstack release cycle
