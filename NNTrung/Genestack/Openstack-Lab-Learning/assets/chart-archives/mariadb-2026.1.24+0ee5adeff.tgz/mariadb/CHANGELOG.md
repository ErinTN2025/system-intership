# Release notes

## 2026.1.0-141

- The chart now ships four namespaced custom resource definitions in the
  ``mariadb.osh.openstack.org/v1alpha1`` API group -- ``Database``, ``User``,
  ``Grant`` and ``Connection`` -- gated by ``.Values.manifests.crds`` (on by
  default; they are inert without any resources to reconcile). They carry
  ``helm.sh/resource-policy: keep`` so that uninstalling the release does not
  cascade-delete the resources and connection secrets that running OpenStack
  services depend on.
  
  The resources are deliberately close to their upstream mariadb-operator
  counterparts. Every field the upstream ``k8s.mariadb.com/v1alpha1``
  resources accept is declared, so a resource written against upstream
  documentation is not silently stripped by the API server, and the status
  subresource is structurally identical to upstream's: a single conditions
  list of ``metav1.Condition``, which means ``kubectl wait
  --for=condition=Ready`` works on all four kinds. Fields this reconciler
  does not implement -- ``passwordPlugin``, ``require.ssl``,
  ``require.issuer``, ``require.subject``, ``maxScaleRef``,
  ``tlsClientCertSecretRef``, the object reference fields that pin a
  referent's identity, and ``optional`` on a secret key reference -- are
  rejected with a ``Ready`` condition of ``False`` rather than ignored, so
  nothing appears to have been honored when it was not. Values that agree
  with what the reconciler already does, such as ``optional: false``, are
  accepted.
  
  A new ``mariadb-db-controller`` deployment, gated by
  ``.Values.manifests.deployment_db_controller`` and **off by default**,
  reconciles those resources: it creates databases, users and grants, and
  materializes connection strings into secrets. It is a single-file Python
  reconciler modelled on the existing ``mariadb-controller``, runs with
  ``replicas: 1`` and no leader election, and reads the administrative
  credentials from ``mariadb-dbadmin-password`` plus ``admin_user.cnf`` (so
  mutual TLS works with no extra configuration). Every operation is
  idempotent and a periodic resync repairs drift made outside the controller.
  
  Enabling the controller adds a key to the ``mariadb-bin`` configmap, whose
  hash annotates the galera statefulset, so it rolls the cluster. Leaving it
  off keeps the rendered chart byte-identical to before.
  
  Also defines ``pod.resources.controller``, which
  ``deployment-controller.yaml`` has always referenced but which was never
  declared in ``values.yaml``.

### New Features

- The ``helm-toolkit.manifests.certificates`` template now accepts an
  optional ``secretName`` parameter. When provided, it sets the name of the
  rendered cert-manager ``Certificate`` (both ``metadata.name`` and
  ``spec.secretName``) instead of deriving it from the endpoint's
  ``host_fqdn_override.default.tls.secretName``.

### Upgrade Notes

- The charts no longer render ``Ingress`` resources, nor the auxiliary
  ``Service`` objects and TLS secrets that used to back them. Charts now
  deploy only the applications and their ClusterIP ``Service`` objects.
  Expose services outside the cluster by supplying the necessary objects
  through the ``.Values.extraObjects`` field, for example a Gateway API
  ``HTTPRoute`` (plus a ``BackendTLSPolicy`` for backend re-encryption) or,
  if preferred, an ``Ingress`` together with its ``Service``. Ready-to-use
  Gateway API examples are provided under
  ``values_overrides/<chart>/gateway.yaml``.
- The mTLS client certificate that each chart presents on outbound
  connections to MariaDB and RabbitMQ is now named after the chart-local
  value ``secrets.tls.client.<chart>`` rather than the shared
  ``endpoints.oslo_db.host_fqdn_override.default.tls.secretName``. This
  prevents a name collision for deployments whose values tooling renders
  endpoints from a single shared endpoint catalog, where the ``oslo_db``
  endpoint (and therefore its ``secretName``) is identical across every
  chart. The pod ``client-certs`` volume already references the same
  chart-local value, so the certificate and its mount remain in lockstep.
  No action is required for existing deployments: the default
  ``secrets.tls.client.<chart>`` value matches the previously rendered
  certificate name.

### API Changes

- Removed all ingress-related values from the charts: the
  ``manifests.ingress*``, ``manifests.service_ingress*`` and
  ``manifests.secret_ingress_tls`` toggles, the ``endpoints.ingress``
  controller endpoint and the ``network.<service>.ingress`` blocks. The
  now-unused ``helm-toolkit.manifests.ingress``,
  ``helm-toolkit.manifests.service_ingress`` and
  ``helm-toolkit.manifests.secret_ingress_tls`` helpers were removed as well.

### Bug Fixes

- Populate ``[cache] memcache_servers`` from the ``oslo_cache`` internal
  memcache endpoint for heat, neutron, trove, and zaqar when a cache section
  exists and ``memcache_servers`` has not already been set by user overrides.
  
  This brings these charts in line with other OpenStack-Helm services that
  already populate ``memcache_servers`` from the ``oslo_cache`` endpoint while
  keeping explicit overrides authoritative.
- Corrected ``rabbit_quorum_queues`` to ``rabbit_quorum_queue`` in every
  chart's ``values.yaml``. The oslo.messaging RabbitMQ driver only
  recognizes the singular option name (see
  `impl_rabbit.py <https://github.com/openstack/oslo.messaging/blob/b5593e2a733bf1ca86be8182f12a17d2d973fb5a/oslo_messaging/_drivers/impl_rabbit.py#L165>`_),
  so the plural form set by every chart since
  Change-Id ``I331e5e86744cbf935a1414399f0dc8e0ce76e4c0`` was silently
  ignored and quorum queues were never actually enabled via that setting.

## 2026.1.0

- Updated to use MariaDB 11.4.8 built on Ubuntu 22.04 (Noble).
- - fixed backup_mariadb_sh script to correctly handle verification during the backup process
- - fixed backup_mariadb_sh script to correctly handle verification during the backup process

### New Features

- Update default ingress classes and annotations for charts to make them implementation
  agnostic. They used to be nginx specific because we always used ingress-nginx as the most
  common choice. Ingress-nginx is deprecated and will become unmaintained in Feb/2026.
  
  Now for all test jobs we use HAProxy Ingress as the default implementation. However any
  other implementation can be used as far as it suppports annotations similar to
  'nginx.ingress.kubernetes.io/rewrite-target' or 'haproxy.org/path-rewrite' which are
  used in many OpenStack-Helm charts.
- Added an extraObjects list to every chart to allow for adding extra
  Kubernetes objects along side the chart without modifying the chart.
  It has the added benefit of using Helm's built in templating so
  you are able to utilize other values supplied to the chart.
- Added emptyDir mounted at /var/lock and set OSLO_LOCK_PATH env var to
  this path for oslo.concurrency support in all OpenStack services.

### Upgrade Notes

- Support for Helm 2 has been removed by removal of the helm3_hook value across all charts.
  It is no longer possible to set helm3_hook to False to support Helm 2.

### Bug Fixes

- Added failover openrc environment variables to database backup cron jobs.
- Replaced deprecated mysql* binaries to their mariadb* equivalents in
  scripts. Also fixed TLS connection for myqsl-exporter side conainers.
- Added failover openrc environment variables to database backup cron jobs.

## 2025.2.0

- The reboot.node annotation wasn't removed after the cluster init is done.
  This happened due to the fact that commit
  c2269d70a23b55c459233ab5fc28362b7c2ca766 removed necessary code lines for
  this and is absolutely needed. So, we are putting these changes back.
- This change applies a fix to the StatefulSet template of the MariaDB chart,
  ensuring that the hash for the exporter secrets is correctly included. This
  is necessary for the proper functioning of the exporter component in the
  MariaDB deployment.
- This change disables TLS for the Prometheus MySQL exporter sidecar container in the MariaDB StatefulSet.

### New Features

- Update apparmor values to use security_context instead of annotations.
- Add support for runtimeClassName and priorityClassName

### Bug Fixes

- In order to fix this issue, the TLS configuration for the Prometheus MySQL exporter sidecar container has been updated to disable TLS. This allows the exporter to connect to the MariaDB database without requiring a CA certificate.

## 2025.1.0

- 0.1.0 Initial Chart
- 0.1.1 Change helm-toolkit dependency version to ">= 0.1.0"
- 0.1.2 mariadb security best practice fixes
- 0.1.3 Fix MariaDB backup script
- 0.1.4 Unpin images built with osh-images
- 0.1.5 Update to container image repo k8s.gcr.io
- 0.1.6 Change Issuer to ClusterIssuer
- 0.1.7 Revert - Change Issuer to ClusterIssuer
- 0.1.8 Change Issuer to ClusterIssuer with logic in place to support cert-manager versioning
- 0.1.9 Uplift Mariadb-ingress to 0.42.0
- 0.1.10 Rename mariadb backup identities
- 0.1.11 Disable mariadb mysql history client logging
- 0.1.12 Set strict permission on mariadb data dir
- 0.1.13 Fix race condition for grastate.dat
- 0.1.14 Update mysqld-exporter image to v0.12.1
- 0.2.0 Uplift mariadb version and ubuntu release
- 0.2.1 Prevent potential splitbrain issue if cluster is in reboot state
- 0.2.2 remove deprecated svc annotation tolerate-unready-endpoints
- 0.2.3 Remove panko residue
- 0.2.4 Use full image ref for docker official images
- 0.2.5 Added helm hook for post-install and post-upgrade in prometheus exporter job.
- 0.2.6 Update log format stream for mariadb
- 0.2.7 add ingress resources
- 0.2.8 Helm 3 - Fix Job labels
- 0.2.9 Update htk requirements
- 0.2.10 Fix Python exceptions
- 0.2.11 Enhance mariadb backup
- 0.2.12 Remove set -x
- 0.2.13 Adjust readiness.sh in single node and no replication case
- 0.2.14 Fix comparison value
- 0.2.15 Updated naming for subchart compatibility
- 0.2.16 Revert naming for subchart compatibility
- 0.2.17 Enable taint toleration for Openstack services jobs
- 0.2.18 Updated naming for subchart compatibility
- 0.2.19 Update default image value to Wallaby
- 0.2.20 Migrated CronJob resource to batch/v1 API version & PodDisruptionBudget to policy/v1; Uplift Mariadb-ingress to 1.1.3
- 0.2.21 Fix mysql exporter user privileges
- 0.2.22 Fix ingress cluster role privileges
- 0.2.23 Fix backup script by ignoring sys database for MariaDB 10.6 compartibility
- 0.2.24 Uplift Mariadb-ingress to 1.2.0
- 0.2.25 Add liveness probe to restart a pod that got stuck in a transfer wsrep_local_state_comment
- 0.2.26 Added OCI registry authentication
- 0.2.27 Fix broken helmrelease for helmv3
- 0.2.28 Added verify_databases_backup_in_directory function implementation
- 0.2.29 Uplift Mariadb-ingress to 1.5.1
- 0.2.30 Replace node-role.kubernetes.io/master with control-plane
- 0.2.31 Update kubernetes registry to registry.k8s.io
- 0.2.32 Prevent liveness probe from killing pods during SST
- 0.2.33 Add 2023.1 Ubuntu Focal overrides
- 0.2.34 Uplift ingress controller image to 1.8.2
- 0.2.35 Update apparmor override
- 0.2.36 Added staggered backups support
- 0.2.37 Backups verification improvements
- 0.2.38 Added throttling remote backups
- 0.2.39 Template changes for image 1.9 compatibility
- 0.2.40 Start.py allows to create mariadb-service-primary service and endpoint
- 0.2.41 Switch to primary service instead of ingress by default
- 0.2.42 Use quay.io/airshipit/kubernetes-entrypoint:latest-ubuntu_focal by default
- 0.2.43 Add 2024.1 Ubuntu Jammy overrides
- 0.2.44 Uplift ingress controller image to 1.11.2
- 0.2.45 Add mariadb controller support
- 0.2.46 Avoid using cluster endpoints
- 0.2.47 Deploy exporter as sidecar
- 0.2.48 Switch to mariadb controller deployment
- 0.2.49 Remove ingress deployment
- 0.2.50 Add cluster-wait job
- 0.2.51 Add 2024.2 overrides
- 0.2.52 Added SSL support to cluster-wait job
- 0.2.53 Use constant for mysql binary name
- 0.2.54 Improve leader election on cold start
- 0.2.55 Improve python3 compatibility
- 0.2.56 Stop running threads on sigkill
- 0.2.57 Remove useless retries on conflicts during cm update
- 0.2.58 Prevent TypeError in get_active_endpoint function
- 0.2.59 Give more time on resolving configmap update conflicts
- 0.2.60 Refactor liveness/readiness probes
- 0.2.61 Avoid using deprecated isAlive()
- 0.2.62 Implement mariadb upgrade during start
- 0.2.63 Use service ip for endpoint discovery
- 0.2.64 Add terminationGracePeriodSeconds
- 0.2.65 Allow to use default storage class
- 0.2.66 Add probes for exporter
- 0.2.67 Update Chart.yaml apiVersion to v2
- 2024.2.0 Update version to align with the Openstack release cycle

## 2024.2.0

Before 2024.2.0 all the OpenStack-Helm charts were versioned independently.
Here we provide all the release notes for the chart for all versions before 2024.2.0.
