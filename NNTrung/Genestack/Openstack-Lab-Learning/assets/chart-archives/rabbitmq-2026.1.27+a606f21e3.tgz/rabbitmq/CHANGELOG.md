# Release notes

## 2026.1.0-143

- Enforce mutual TLS on the AMQP listener by setting
  ssl_options.fail_if_no_peer_cert to true in the TLS value overrides. Clients
  must present a client certificate signed by the trusted CA to connect.
- The chart now ships seven namespaced custom resource definitions in the
  ``rabbitmq.osh.openstack.org/v1alpha1`` API group -- ``Vhost``, ``User``,
  ``Permission``, ``Queue``, ``Exchange``, ``Binding`` and ``Policy`` --
  gated by ``.Values.manifests.crds`` (on by default; they are inert without
  any resources to reconcile). They carry ``helm.sh/resource-policy: keep``
  so that uninstalling the release does not cascade-delete the messaging
  accounts every running OpenStack service depends on.
  
  The resources are compatible with the upstream
  messaging-topology-operator: apart from the API group they are its
  ``rabbitmq.com/v1beta1`` resources, so a resource written against upstream
  documentation applies unchanged and the same consumer chart templates can be
  pointed at either implementation -- retargeting them at that operator also
  means replacing ``rabbitmqClusterReference.name`` with a
  ``connectionSecret``, because upstream resolves the name to a
  ``RabbitmqCluster`` resource which this chart does not create. There is
  deliberately no ``Connection`` kind, because upstream has none: nothing in
  ``rabbitmq.com/v1beta1`` carries a broker address, and a chart already knows
  the address from its ``endpoints.oslo_messaging`` values. Every field
  upstream accepts is declared, so nothing is silently stripped by the API
  server, the ``rabbitmqClusterReference`` schema carries the exactly-one-of
  rule upstream enforces with an admission webhook, and the status
  subresource is structurally identical to upstream's: ``observedGeneration``
  plus a conditions list, which means ``kubectl wait --for=condition=Ready``
  works on all seven kinds, and only the two reasons upstream defines are ever
  written. Every declared field is implemented, so nothing is refused. A
  ``rabbitmqClusterReference`` that names a broker this reconciler does not
  serve -- by ``name``, by ``connectionSecret``, or by a ``namespace`` other
  than its own -- means the resource belongs to something else, so it is left
  completely untouched: not declared against this broker, and not written to
  either, because status belongs to whichever controller does serve it and two
  writers would flap against each other. That is what lets this reconciler and
  the upstream operator share a namespace; the reconciler log records what it
  skipped and why.
  
  A new ``rabbitmq-topology-controller`` deployment, gated by
  ``.Values.manifests.deployment_topology_controller`` and **off by
  default**, reconciles those resources over the RabbitMQ HTTP management
  API. It is a single-file Python reconciler built on the official
  ``kubernetes`` client and ``requests``, so it needs an image carrying both
  and defaults to ``openstack-client``, which the chart already pulls for its
  ``rabbitmq-password`` init container.
  It runs with ``replicas: 1`` and no leader election, and reads
  the administrative account from the chart's own ``<release>-admin-user``
  secret. Every operation is idempotent and a periodic resync repairs drift
  made outside the controller.
  
  That resync also fixes a long-standing problem. The chart declares the
  ``guest`` account in ``definitions.json``, which
  ``management.load_definitions`` imports on every node boot, while
  ``loopback_users.guest`` is ``false`` -- so the account can log in from
  anywhere, and the one-shot deletion each consumer chart's rabbit-init job
  performs does not survive a node restart. With
  ``RABBITMQ_TOPOLOGY_CONTROLLER_DELETE_GUEST_USER`` (on by default in
  ``pod.env.rabbitmq_topology_controller``) the account is removed on every
  sweep instead.
  
  Enabling the controller adds a key to the ``rabbitmq-bin`` configmap, whose
  hash annotates the server statefulset, so it rolls the cluster. Leaving it
  off keeps the rendered chart identical to before apart from the inert
  definitions.
- Raise the broker's open-file limit to 65536 (pod.nofile.server) before
  starting it. RabbitMQ sizes its whole file-handle budget from the soft
  limit it sees at boot, and that budget covers the segment and WAL files of
  every quorum queue as well as client sockets. With the runtime default of
  1024 the broker logged "Limiting to approx 927 file handles (832 sockets)",
  and a deployment with a few hundred quorum queues left only about 180
  handles for sockets. Past that it stopped admitting connections, letting a
  new one in only as an old one closed, so clients sat unanswered until they
  gave up. The limit is capped at the container's hard limit; set
  pod.nofile.server to null to leave the inherited limit alone.
- ``conf.rabbitmq.queue_master_locator`` becomes
  ``queue_leader_locator: balanced``.
- The helm test pod queries the HTTP management API instead of
  ``rabbitmqadmin`` and moves to a new ``images.tags.rabbitmq_test``.
  ``scripted_test`` keeps a rabbitmq image for the cluster-wait job.

### New Features

- The ``helm-toolkit.manifests.certificates`` template now accepts an
  optional ``secretName`` parameter. When provided, it sets the name of the
  rendered cert-manager ``Certificate`` (both ``metadata.name`` and
  ``spec.secretName``) instead of deriving it from the endpoint's
  ``host_fqdn_override.default.tls.secretName``.

### Upgrade Notes

- The charts no longer render ``Ingress`` resources, nor the auxiliary
  ``Service`` objects and TLS secrets that used to back them. Charts now
  deploy only the applications and their ClusterIP ``Service`` objects.
  Expose services outside the cluster by supplying the necessary objects
  through the ``.Values.extraObjects`` field, for example a Gateway API
  ``HTTPRoute`` (plus a ``BackendTLSPolicy`` for backend re-encryption) or,
  if preferred, an ``Ingress`` together with its ``Service``. Ready-to-use
  Gateway API examples are provided under
  ``values_overrides/<chart>/gateway.yaml``.
- The mTLS client certificate that each chart presents on outbound
  connections to MariaDB and RabbitMQ is now named after the chart-local
  value ``secrets.tls.client.<chart>`` rather than the shared
  ``endpoints.oslo_db.host_fqdn_override.default.tls.secretName``. This
  prevents a name collision for deployments whose values tooling renders
  endpoints from a single shared endpoint catalog, where the ``oslo_db``
  endpoint (and therefore its ``secretName``) is identical across every
  chart. The pod ``client-certs`` volume already references the same
  chart-local value, so the certificate and its mount remain in lockstep.
  No action is required for existing deployments: the default
  ``secrets.tls.client.<chart>`` value matches the previously rendered
  certificate name.
- RabbitMQ 4.3.5 is now the default, replacing 3.10.18 for the broker and
  3.13-management for the rabbit-init jobs. This is **not an in-place
  upgrade**: 3.10 to 4.x is unsupported. Either step the broker through 3.13
  with all feature flags enabled, or wipe it and rerun the rabbit-init jobs.
- ``ha-mode`` and ``ha-sync-mode`` are dropped from the ``ha_ttl_<service>``
  policies and ``rabbit_ha_queues`` becomes ``false``, since 4.x removed
  classic queue mirroring. Policies left over from 3.x must be deleted by
  hand. The former ``values_overrides/<chart>/rabbitmq4.yaml`` files are now
  the default and have been removed.
- Every chart that talks to RabbitMQ now sets ``amqp_durable_queues``,
  ``rabbit_quorum_queues``, ``rabbit_transient_quorum_queue`` and
  ``use_queue_manager`` to ``true``, which 4.x requires. Twelve charts gain
  an ``oslo_messaging_rabbit`` section. Use quorum queues for high
  availability in place of mirroring.

### API Changes

- Removed all ingress-related values from the charts: the
  ``manifests.ingress*``, ``manifests.service_ingress*`` and
  ``manifests.secret_ingress_tls`` toggles, the ``endpoints.ingress``
  controller endpoint and the ``network.<service>.ingress`` blocks. The
  now-unused ``helm-toolkit.manifests.ingress``,
  ``helm-toolkit.manifests.service_ingress`` and
  ``helm-toolkit.manifests.secret_ingress_tls`` helpers were removed as well.

### Bug Fixes

- Populate ``[cache] memcache_servers`` from the ``oslo_cache`` internal
  memcache endpoint for heat, neutron, trove, and zaqar when a cache section
  exists and ``memcache_servers`` has not already been set by user overrides.
  
  This brings these charts in line with other OpenStack-Helm services that
  already populate ``memcache_servers`` from the ``oslo_cache`` endpoint while
  keeping explicit overrides authoritative.
- Corrected ``rabbit_quorum_queues`` to ``rabbit_quorum_queue`` in every
  chart's ``values.yaml``. The oslo.messaging RabbitMQ driver only
  recognizes the singular option name (see
  `impl_rabbit.py <https://github.com/openstack/oslo.messaging/blob/b5593e2a733bf1ca86be8182f12a17d2d973fb5a/oslo_messaging/_drivers/impl_rabbit.py#L165>`_),
  so the plural form set by every chart since
  Change-Id ``I331e5e86744cbf935a1414399f0dc8e0ce76e4c0`` was silently
  ignored and quorum queues were never actually enabled via that setting.

## 2026.1.0

- Removing rabbitmq exporter due to EOL. Converted to use
  built-in metrics instead.

### New Features

- Update default ingress classes and annotations for charts to make them implementation
  agnostic. They used to be nginx specific because we always used ingress-nginx as the most
  common choice. Ingress-nginx is deprecated and will become unmaintained in Feb/2026.
  
  Now for all test jobs we use HAProxy Ingress as the default implementation. However any
  other implementation can be used as far as it suppports annotations similar to
  'nginx.ingress.kubernetes.io/rewrite-target' or 'haproxy.org/path-rewrite' which are
  used in many OpenStack-Helm charts.
- Added an extraObjects list to every chart to allow for adding extra
  Kubernetes objects along side the chart without modifying the chart.
  It has the added benefit of using Helm's built in templating so
  you are able to utilize other values supplied to the chart.
- Added emptyDir mounted at /var/lock and set OSLO_LOCK_PATH env var to
  this path for oslo.concurrency support in all OpenStack services.

### Upgrade Notes

- Support for Helm 2 has been removed by removal of the helm3_hook value across all charts.
  It is no longer possible to set helm3_hook to False to support Helm 2.

## 2025.2.0

### New Features

- Update apparmor values to use security_context instead of annotations.
- Add support for runtimeClassName and priorityClassName

## 2025.1.0

- 0.1.0 Initial Chart
- 0.1.1 Change helm-toolkit dependency version to ">= 0.1.0"
- 0.1.2 changes rmq-exporter secret src
- 0.1.4 Add configurable RABBIT_TIMEOUT parameter
- 0.1.5 Update Rabbitmq exporter version
- 0.1.6 Disallow privilege escalation in rabbitmq server container
- 0.1.7 Adding TLS logic to rabbitmq
- 0.1.8 Make helm test work with TLS
- 0.1.9 Use full image ref for docker official images
- 0.1.10 Set separate for HTTPS
- 0.1.11 Add TLS support for helm test
- 0.1.12 Added helm hook post-install and post-upgrade for rabbitmq wait cluster job
- 0.1.13 Add prestop action and version 3.8.x upgrade prep
- 0.1.14 Update readiness and liveness probes
- 0.1.15 Update htk requirements
- 0.1.16 Add force_boot command to rabbit start template
- 0.1.17 Updated naming for subchart compatibility
- 0.1.18 Revert naming for subchart compatibility
- 0.1.19 Enable taint toleration for Openstack services jobs
- 0.1.20 Bump Rabbitmq version to 3.9.0
- 0.1.21 Updated naming for subchart compatibility
- 0.1.22 Remove guest admin account
- 0.1.23 Fixed guest account removal
- 0.1.24 Added OCI registry authentication
- 0.1.25 Add hostPort support
- 0.1.26 Moved guest admin removal to init template
- 0.1.27 Replace node-role.kubernetes.io/master with control-plane
- 0.1.28 Add IPv6 environment support for rabbitmq
- 0.1.29 Add build-in prometheus plugin and disable external exporter
- 0.1.30 Add labels to rabbitmq service
- 0.1.31 Support management api metrics collection
- 0.1.32 Enable addition of default consumer prefetch count
- 0.1.33 Bump RabbitMQ image version to 3.13.0
- 0.1.34 Add 2024.1 overrides
- 0.1.35 Add configurable probes to rabbitmq container
- 0.1.36 Use quay.io/airshipit/kubernetes-entrypoint:latest-ubuntu_focal by default
- 0.1.37 Update rabbitmq readiness/liveness command
- 0.1.38 Do not use hardcoded username in rabbitmq chown container
- 0.1.39 Allow to bootstrap rabbitmq with initial config
- 0.1.40 Set password for guest user rabbitmq
- 0.1.41 Use short rabbitmq node name
- 0.1.42 Revert Use short rabbitmq node name
- 0.1.43 Add 2024.2 overrides
- 0.1.44 Allow to use default storage class
- 0.1.45 Update Chart.yaml apiVersion to v2
- 2024.2.0 Update version to align with the Openstack release cycle

## 2024.2.0

Before 2024.2.0 all the OpenStack-Helm charts were versioned independently.
Here we provide all the release notes for the chart for all versions before 2024.2.0.
